#include <stdio.h>
#include "RC5.c"
void RC5(char* key2, char* v1, char* v2,unsigned int* ct0_ret);
