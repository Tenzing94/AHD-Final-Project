# AHD-Final-Project
Final Project for Advanced Hardware Design @ NYU Tandon, Fall 2018 Semester


## How to contribute: 

* Fork this repo
* Work in a branch
* done adding things/features/bug fixes? Submit a pull request from your forked branch
* Everyone gets notified. One person reviews the other's code, this will ensure merge conflicts dont exist as well as 

* Reference for these practices: https://learn.adafruit.com/contribute-to-circuitpython-with-git-and-github/grab-your-fork
